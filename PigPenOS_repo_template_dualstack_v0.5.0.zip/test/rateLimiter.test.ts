import { createRateLimiter } from "../src/rateLimiter";

test("blocks after max hits within window", () => {
  const rl = createRateLimiter({ windowMs: 60_000, max: 2 });
  expect(rl.allow("ip:1")).toBe(true);
  expect(rl.allow("ip:1")).toBe(true);
  expect(rl.allow("ip:1")).toBe(false);
});
