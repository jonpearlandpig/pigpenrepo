# PigPen OS — Pearl & Pig Repo
## Bring Your Pearls. Make Them Mean Something.

TID: TID-PPOS-0001
TAID: TAID-PPOS-TEMPLATE-0005
Version: v0.5.0

## What this repo does
- Runs PigPenOS from GitHub issue comments (NTL).
- Always posts a PLAN.
- Can IMPLEMENT (apply patch + test + open PR) only when a patch service is configured.

## NTL examples
- `pigpen plan this change and keep it small`
- `pigpen breakdown steps + files likely impacted`
- `pigpen implement and open a PR`

## IMPLEMENT requirements
Repo secrets:
- `PIGPEN_LLM_ENDPOINT` (e.g. http://localhost:8787 or your hosted service)
- `PIGPEN_API_KEY`

## Governance
PigPenOS refuses IMPLEMENT if patch touches any protected prefixes:
- 00_README_GOVERNANCE/
- 01_CANON/
- .github/workflows/
- tools/pigpen/

## Included patch services
- `tools/patch_service_mock_node` (deterministic local mock)
- `tools/patch_service_prod_python` (FastAPI template; wire generate_patch())
