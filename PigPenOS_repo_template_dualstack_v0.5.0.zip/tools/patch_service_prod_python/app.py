"""
PigPen Production Patch Service Template (FastAPI)
TID: TID-PPOS-0001
TAID: TAID-PPOS-PRODSVC-0001
Version: v1.0
"""

from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel, Field
from typing import List, Literal, Optional

app = FastAPI(title="PigPen Patch Service", version="1.0")

class Meta(BaseModel):
    tid: str
    taid: str
    version: str
    repo: str
    issue_number: int
    base_branch: str

class Intent(BaseModel):
    issue_title: str
    issue_body: str
    comment_body: str

class Constraints(BaseModel):
    max_files: int = 10
    max_diff_lines: int = 400
    must_include_tests: bool = True
    forbidden_paths: List[str] = Field(default_factory=list)

class ContextFile(BaseModel):
    path: str
    content: str

class PatchRequest(BaseModel):
    meta: Meta
    intent: Intent
    constraints: Constraints
    context_files: List[ContextFile] = Field(default_factory=list)

class Validation(BaseModel):
    tests_included: bool
    forbidden_paths_touched: bool
    estimated_diff_lines: int

class PatchOk(BaseModel):
    status: Literal["ok"] = "ok"
    summary: str
    risk: Literal["low", "medium", "high"]
    files_changed: List[str]
    patch: str
    validation: Validation

class PatchRefused(BaseModel):
    status: Literal["refused"] = "refused"
    reason: str
    risk: Literal["low", "medium", "high"]

class PatchError(BaseModel):
    status: Literal["error"] = "error"
    reason: str

def require_auth(authorization: Optional[str]) -> None:
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="missing auth")

@app.get("/health")
def health(authorization: Optional[str] = Header(default=None)):
    require_auth(authorization)
    return {"status": "ok"}

@app.post("/pigpen/patch", response_model=PatchOk | PatchRefused | PatchError)
async def patch(
    req: PatchRequest,
    authorization: Optional[str] = Header(default=None),
    x_pigpen_version: Optional[str] = Header(default=None),
):
    require_auth(authorization)

    if x_pigpen_version != "1.0":
        return PatchError(reason="unsupported X-PigPen-Version (expected 1.0)")

    combined = (req.intent.issue_title + " " + req.intent.comment_body + " " + req.intent.issue_body).lower()
    for pre in req.constraints.forbidden_paths:
        if pre.lower() in combined:
            return PatchRefused(reason="Request text references forbidden paths.", risk="high")

    # IMPLEMENTATION POINT:
    # Wire this to GARVIS / GoGarvis patch generator.
    return PatchRefused(reason="Production template not wired to a patch generator yet.", risk="low")
