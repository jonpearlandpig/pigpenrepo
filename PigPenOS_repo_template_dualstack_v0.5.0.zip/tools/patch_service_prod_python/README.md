# PigPen Patch Service (Production Template — Python/FastAPI)

TID: TID-PPOS-0001
TAID: TAID-PPOS-PRODSVC-0001
Version: v1.0

## Run
python -m venv .venv
source .venv/bin/activate
pip install -e .
uvicorn app:app --host 0.0.0.0 --port 8787

## Endpoints
- GET /health
- POST /pigpen/patch

## Wiring
Replace the refusal in /pigpen/patch with your real patch generator that returns:
- unified diff patch
- summary
- files_changed
- validation metadata
