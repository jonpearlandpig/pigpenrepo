/**
 * PigPen Mock Patch Service (Deterministic)
 * TID: TID-PPOS-0001
 * TAID: TAID-PPOS-MOCKSVC-0001
 * Version: v1.0
 */

import express from "express";

const app = express();
app.use(express.json({ limit: "5mb" }));

function authOK(req) {
  const h = req.headers["authorization"] || "";
  return h.startsWith("Bearer ");
}

app.get("/health", (req, res) => {
  if (!authOK(req)) return res.status(401).json({ status: "error", reason: "missing auth" });
  return res.json({ status: "ok" });
});

app.post("/pigpen/patch", (req, res) => {
  if (!authOK(req)) return res.status(401).json({ status: "error", reason: "missing auth" });

  const body = req.body || {};
  const title = body?.intent?.issue_title || "";
  const comment = body?.intent?.comment_body || "";
  const forbidden = body?.constraints?.forbidden_paths || [];

  const combined = (title + " " + comment).toLowerCase();
  if (forbidden.some((p) => combined.includes(String(p).toLowerCase()))) {
    return res.json({ status: "refused", reason: "Request mentions forbidden paths.", risk: "high" });
  }

  if (combined.includes("rate limit") || combined.includes("rate limiter")) {
    const patch = [
      "diff --git a/src/rateLimiter.ts b/src/rateLimiter.ts",
      "index e69de29..1111111 100644",
      "--- a/src/rateLimiter.ts",
      "+++ b/src/rateLimiter.ts",
      "@@ -0,0 +1,28 @@",
      "+export type RateLimiter = { allow: (key: string) => boolean };",
      "+",
      "+export function createRateLimiter(opts: { windowMs: number; max: number }): RateLimiter {",
      "+  const hits = new Map<string, { count: number; resetAt: number }>();",
      "+",
      "+  return {",
      "+    allow(key: string) {",
      "+      const now = Date.now();",
      "+      const entry = hits.get(key);",
      "+",
      "+      if (!entry || now >= entry.resetAt) {",
      "+        hits.set(key, { count: 1, resetAt: now + opts.windowMs });",
      "+        return true;",
      "+      }",
      "+      if (entry.count >= opts.max) return false;",
      "+",
      "+      entry.count += 1;",
      "+      return true;",
      "+    },",
      "+  };",
      "+}",
      "",
      "diff --git a/test/rateLimiter.test.ts b/test/rateLimiter.test.ts",
      "index e69de29..2222222 100644",
      "--- a/test/rateLimiter.test.ts",
      "+++ b/test/rateLimiter.test.ts",
      "@@ -0,0 +1,10 @@",
      "+import { createRateLimiter } from "../src/rateLimiter";",
      "+",
      "+test("blocks after max hits within window", () => {",
      "+  const rl = createRateLimiter({ windowMs: 60_000, max: 2 });",
      "+  expect(rl.allow("ip:1")).toBe(true);",
      "+  expect(rl.allow("ip:1")).toBe(true);",
      "+  expect(rl.allow("ip:1")).toBe(false);",
      "+});",
      ""
    ].join("\n");

    return res.json({
      status: "ok",
      summary: "Adds a minimal in-memory rate limiter with unit tests (deterministic mock).",
      risk: "medium",
      files_changed: ["src/rateLimiter.ts", "test/rateLimiter.test.ts"],
      patch,
      validation: {
        tests_included: true,
        forbidden_paths_touched: false,
        estimated_diff_lines: 60
      }
    });
  }

  return res.json({
    status: "refused",
    reason: "Mock server only supports rate limiter demo intents. Provide a real patch service for other changes.",
    risk: "low"
  });
});

const port = process.env.PORT || 8787;
app.listen(port, () => console.log(`PigPen mock patch service listening on :${port}`));
