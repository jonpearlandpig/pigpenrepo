# PigPen Mock Patch Service (Node)

TID: TID-PPOS-0001
TAID: TAID-PPOS-MOCKSVC-0001
Version: v1.0

## Run
npm i
npm start

## Configure repo secrets (for GitHub Actions IMPLEMENT)
PIGPEN_LLM_ENDPOINT=http://<host>:8787
PIGPEN_API_KEY=<any string accepted by mock>

## Endpoints
GET /health
POST /pigpen/patch

## Purpose
Deterministic patches for demo/testing without a real LLM.
Supports only rate limiter intents. Otherwise refuses.
