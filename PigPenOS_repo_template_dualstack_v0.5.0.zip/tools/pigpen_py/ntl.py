from .types import PigPenAction

def infer_action_from_ntl(text: str) -> PigPenAction:
    t = (text or "").lower()

    if any(h in t for h in ["implement", "build", "code", "open a pr", "ship", "create pr"]):
        return "IMPLEMENT"
    if any(h in t for h in ["plan", "scope", "breakdown", "steps", "approach"]):
        return "PLAN"
    if any(h in t for h in ["fix ci", "tests failing", "lint", "typecheck", "failing pipeline"]):
        return "FIX_CI"
    return "UNKNOWN"
