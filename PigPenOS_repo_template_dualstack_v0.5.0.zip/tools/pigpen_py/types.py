from dataclasses import dataclass
from typing import List, Literal

PigPenRisk = Literal["low", "medium", "high"]
PigPenAction = Literal["PLAN", "IMPLEMENT", "FIX_CI", "UNKNOWN"]

@dataclass
class PigPenPlan:
    tid: str
    taid: str
    version: str
    action: PigPenAction
    intent: str
    domain: str
    risk: PigPenRisk
    two_key_required: bool
    files_likely: List[str]
    steps: List[str]
    tests: List[str]
    rollback: str
