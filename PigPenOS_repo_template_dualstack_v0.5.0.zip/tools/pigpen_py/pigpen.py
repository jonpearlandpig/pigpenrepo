import argparse, json
from tools.pigpen_py.ntl import infer_action_from_ntl
from tools.pigpen_py.router import route

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--issue-title", required=True)
    p.add_argument("--issue-body", default="")
    p.add_argument("--comment", required=True)
    args = p.parse_args()

    action = infer_action_from_ntl(args.comment)
    plan = route(action, args.issue_title, args.issue_body, args.comment)
    print(json.dumps(plan.__dict__, indent=2))

if __name__ == "__main__":
    main()
