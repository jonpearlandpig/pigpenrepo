from .types import PigPenPlan, PigPenRisk, PigPenAction

def _risk(text: str) -> PigPenRisk:
    s = text.lower()
    if any(k in s for k in ["auth", "payment", "security"]):
        return "high"
    if any(k in s for k in ["rate", "limit", "middleware"]):
        return "medium"
    return "low"

def route(action: PigPenAction, issue_title: str, issue_body: str, comment_body: str) -> PigPenPlan:
    text = f"{issue_title}\n{issue_body or ''}\n{comment_body or ''}".strip()
    risk = _risk(text)

    intent = "add_rate_limiter" if "rate limit" in text.lower() else "general_change"
    domain = "ops" if any(k in text.lower() for k in ["api", "endpoint"]) else "projects"

    files_likely = ["src/rateLimiter.ts", "src/index.ts", "test/rateLimiter.test.ts"] if intent == "add_rate_limiter" else ["src/index.ts"]
    steps = [
        "Add a rate limiter module with a small, testable surface.",
        "Wire limiter into app entrypoint.",
        "Add unit tests covering limit exceeded behavior.",
        "Run CI (tests) and open PR with summary + rollback note.",
    ] if intent == "add_rate_limiter" else ["Implement minimal change with tests, keep PR small."]

    tests = ["npm test (unit)"] if intent == "add_rate_limiter" else ["npm test"]
    rollback = "Revert PR; limiter is isolated to rateLimiter.ts + one import." if intent == "add_rate_limiter" else "Revert PR."

    return PigPenPlan(
        tid="TID-PPOS-0001",
        taid="TAID-PPOS-PLAN-0004",
        version="v0.5.0",
        action=action,
        intent=intent,
        domain=domain,
        risk=risk,
        two_key_required=False,
        files_likely=files_likely,
        steps=steps,
        tests=tests,
        rollback=rollback,
    )
