export type RateLimiter = { allow: (key: string) => boolean };

export function createRateLimiter(opts: { windowMs: number; max: number }): RateLimiter {
  const hits = new Map<string, { count: number; resetAt: number }>();

  return {
    allow(key: string) {
      const now = Date.now();
      const entry = hits.get(key);

      if (!entry || now >= entry.resetAt) {
        hits.set(key, { count: 1, resetAt: now + opts.windowMs });
        return true;
      }
      if (entry.count >= opts.max) return false;

      entry.count += 1;
      return true;
    },
  };
}
